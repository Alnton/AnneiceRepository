#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main(){
  int fd = open("a.txt",O_CREAT|O_RDWR|O_TRUNC,0666);
  if(fd==-1) perror("open"),exit(-1);
  int res = write(fd,"hello",5);
  printf("写了%d字节\n",res);
  close(fd);
}


