#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
struct emp{
  int id;
  char name[20];
  double sal; };
int main(){
  int fd = open("emp.dat",O_RDWR);
  if(fd==-1) perror("open"),exit(-1);
  struct emp em;
  int res = read(fd,&em,sizeof(em));
  if(res != -1) {
     printf("%d,%s,%lf\n",em.id,em.name,
      em.sal); }
  else printf("read error\n");
  close(fd);
}


