#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(){
  void* p = sbrk(4);
  int *pi = p;
  *pi = 100;
  double* pd = sbrk(8);
  *pd = 3.14;
  char* str = sbrk(10);
  strcpy(str,"hello");
  printf("%d,%lf,%s\n",*pi,*pd,str);
  brk(p);
  return 0;
}

