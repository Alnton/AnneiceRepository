#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
int main(){
  void* p = sbrk(0);
  int r = brk(p+4);//分配4字节
  if(r == -1) perror("brk"),exit(-1);
  brk(p+8);//新分配4个字节
  brk(p+4);//释放4字节
  int *pi = p; *pi = 100;
  char* st = sbrk(0);
  brk(st+10);//分配10字节
  //st = "abcd";//改变指针的指向(地址)，不对
  strcpy(st,"abcd");//改值，正确
  int* pi2 = sbrk(0);
  brk(pi2+4); *pi2 = 200;
  brk(pi2); brk(p);//全部释放
}

