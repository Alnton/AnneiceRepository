#include <stdio.h>
#include <sys/mman.h>
#include <string.h>

int main(){
  void* p = mmap(0,//首地址，0代表 内核选择
                 4,//大小，不足一个内存页补足
                 PROT_READ|PROT_WRITE,//权限
                 MAP_ANONYMOUS|MAP_PRIVATE,
                 0,0);
  if(p == MAP_FAILED) perror("mmap"),exit(-1);
  int* pi = p; *pi = 100;
  char* str = p+4;  strcpy(str,"abcdef");
  char* pc = p; int i;
  for(i=0;i<20;i++){
    printf("%d\n",pc[i]);//*(pc+i)
  }
  munmap(p,4);
  return 0;
}

