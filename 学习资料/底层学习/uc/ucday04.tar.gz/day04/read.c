#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main(){
  int fd = open("a.txt",O_RDONLY);
  if(fd == -1) perror("opon"),exit(-1);
  char buf[100] = {};
  int res = read(fd,buf,sizeof(buf));
  if(res == -1) perror("read"),exit(-1);
  printf("读到了%d字节，内容:%s\n",res,buf);
  close(fd);
}

