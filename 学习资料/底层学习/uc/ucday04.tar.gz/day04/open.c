#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
  printf("O_RDONLY=%d,O_WRONLY=%d,O_RDWR=%d\n"
    ,O_RDONLY,O_WRONLY,O_RDWR);
  printf("O_CREAT=%d\n",O_CREAT);
  printf("O_APPEND=%d\n",O_APPEND);
  printf("O_TRUNC=%d\n",O_TRUNC);
 //如果新建文件，必须指定权限
 //指定权限可能被系统屏蔽部分
  int fd = open("a.txt",O_CREAT|O_RDWR,0666);
  if(fd == -1) perror("open"),exit(-1);
  printf("opne ok!\n");
  close(fd);
}


