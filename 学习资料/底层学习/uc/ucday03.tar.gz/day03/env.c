#include <stdio.h>
#include <stdlib.h>
//
int main(int argc,char** argv,char** env){
  extern char** environ;//和env一样
  printf("%p,%p\n",environ,env);
  char* value = getenv("LANG");
  printf("value=%s\n",value);
  putenv("VAR=aaa");
  printf("VAR=%s\n",getenv("VAR"));//aaa
  putenv("VAR=111");//替换
  printf("VAR=%s\n",getenv("VAR"));//111
  setenv("VAR","123",0);//不替换
  printf("VAR=%s\n",getenv("VAR"));//111
  setenv("VAR","456",1);//替换
  printf("VAR=%s\n",getenv("VAR"));//456
  clearenv();//删除所有的环境变量
}

