#include <stdio.h>
int a = 10;
int main(){
  int x = 0;
  printf("%p\n",&a);
}

