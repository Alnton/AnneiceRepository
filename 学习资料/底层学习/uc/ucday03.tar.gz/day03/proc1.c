#include <stdio.h>

int main(){
  int x = 100;
  printf("x=%d,&x=%p\n",x,&x);
  while(1);
}

