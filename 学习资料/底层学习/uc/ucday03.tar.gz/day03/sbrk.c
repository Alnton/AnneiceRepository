#include <stdio.h>
#include <unistd.h>

int main(){
  printf("pid=%d\n",getpid());
  void* p1 = sbrk(4);//分配4字节内存
  void* p2 = sbrk(4);
  void* p3 = sbrk(4); void* p4 = sbrk(4);
  printf("p1=%p,p2=%p,p3=%p,p4=%p\n",p1,p2,
    p3,p4);
  sbrk(-4);//释放4字节内存
  sbrk(-8);
  void* cur = sbrk(0);
  printf("cur=%p\n",cur);
  getchar(); sbrk(4093); printf("超了\n");
  getchar();  sbrk(-1); printf("回来了\n");
  while(1);
}

