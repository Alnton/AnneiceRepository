#include <stdio.h>
#include <stdlib.h>

int main(){
  int a,b,c;//栈
  printf("a=%p,b=%p,c=%p\n",&a,&b,&c);
  int* p1 = malloc(4);//堆
  int* p2 = malloc(4);//内存虽已映射，但使用时
  int* p3 = malloc(4);//还是要再次malloc
  printf("p1=%p,p2=%p,p3=%p\n",p1,p2,p3);
  *(p1+100) = 10;//映射了33个内存页
  printf("%d\n",*(p1+100));
  //*(p1-1) = 0;//附加数据存在
  free(p1);//malloc的大小和使用的大小保持一致
  while(1);
}

