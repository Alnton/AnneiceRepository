#include <stdio.h>
#include <string.h>

int main(){
  char* s1 = "abcd";//只读区
  char s2[] = "abcd";//栈区，数组都是常指针
  char*	 s3 = s2;//栈区
  printf("s1=%p\n",s1);
  s1 = "1234";//可以改地址
  printf("s1=%p\n",s1);
  //s2 = "1234";//常指针(字符数组)不能直接赋值
  //s3 = "1234";//可以改地址
  //strcpy(s1,"A");//只读区不能改值
  //s1[0] = 'A';//同上
  strcpy(s2,"ABCD");//可以改值
  printf("s2=%s\n",s2);
  strcpy(s3,"ABCD");//如果指向只读区不能改值
}

