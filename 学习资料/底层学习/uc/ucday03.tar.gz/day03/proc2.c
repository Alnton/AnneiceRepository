#include <stdio.h>

int main(){
  int* p = 0xbfd7708c;
  printf("*p=%d\n",*p);
}


