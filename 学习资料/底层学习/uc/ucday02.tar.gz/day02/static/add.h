#ifndef ADD_H_
#define ADD_H_//防止重复被导入
int add(int,int);
double add2(double,double);
#endif
