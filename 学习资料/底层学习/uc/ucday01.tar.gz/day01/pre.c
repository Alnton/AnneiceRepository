#include <stdio.h>
#define VERSION 3
#if(VERSION < 3)
  #error "版本过低"
#elif(VERSION > 3)
  #warning "版本高"
#endif
#pragma GCC dependency "hello.c"
#define GO goto
#pragma GCC poison goto//下面代码不能使用goto
//#pragma GCC poison int
#pragma pack(2)// 1 按2的整数倍对齐和补齐
int main(){
  printf("hello c\n");
  //goto ok;
  GO ok;//可以通过先定义宏而后使用的方式
  printf("one\n");
  ok:printf("two\n");
  struct s{
    char c;
    int i;
    char ch;
  };
  printf("size=%d\n",sizeof(struct s));
  return 0;
}

