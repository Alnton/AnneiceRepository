//对头文件中的变量进行定义
#include "bank.h"

const int key1 = 0x12345678;
const int key2 = 0x23456789;
