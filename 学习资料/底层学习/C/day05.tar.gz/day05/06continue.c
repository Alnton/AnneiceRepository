/*
   continue;演示
   */
#include <stdio.h>
int main() {
	int num = 0;
	for (num = 1;num <= 5;num++) {
		if (num == 3) {
			continue;
		}
		printf("%d ", num);
	}
	printf("\n");
	return 0;
}
