/*
   for练习
   */
#include <stdio.h>
int main() {
	int num = 0;
	for (num = 99;num >= 1;num -= 2) {
		printf("%d ", num);
	}
	printf("\n");
	return 0;
}
