/*
   while循环实现猜数游戏
   */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
	int guess = 0, num = 0;
	srand(time(0));
	//guess = rand() % 100 + 1;
	guess = 0;
	do {
		printf("请猜一个数字：");
		scanf("%d", &num);
        if (guess < num) {
			printf("猜大了\n");
		}
		else if (guess == num) {
			printf("猜对了\n");
		}
		else {
			printf("猜小了\n");
		}
	} while (guess != num);
	return 0;
}




