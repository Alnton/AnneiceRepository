/*
   for练习
   */
#include <stdio.h>
int main() {
	int num = 1;
	for (;;) {
		if (num == 6) {
			break;
		}
		printf("%d ", num);
		num++;
	}
	printf("\n");
	return 0;
}
