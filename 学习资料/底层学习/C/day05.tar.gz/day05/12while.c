/*
   while循环演示
   */
#include <stdio.h>
int main() {
	int num = 1;
	while (1) {
		if (num == 6) {
			break;
		}
		printf("%d ", num);
		num++;
	}
	printf("\n");
	return 0;
}
