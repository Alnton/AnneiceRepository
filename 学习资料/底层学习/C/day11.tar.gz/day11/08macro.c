/*
   宏练习
   */
#include <stdio.h>
#define   SUB(x, y)       ((x) - (y))
#define   SQUARE(n)       ((n) * (n))
int main() {
	int num = 5;
	printf("SUB(7, 3)是%d\n", SUB(7, 3));
	printf("20 - SUB(10, 5)是%d\n", 20 - SUB(10, 5));
	printf("SUB(20, 10 - 5)是%d\n", SUB(20, 10 - 5));
	printf("SQUARE(++num)是%d\n", SQUARE(++num));
	return 0;
}
