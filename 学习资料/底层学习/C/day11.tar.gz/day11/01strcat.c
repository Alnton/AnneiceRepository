/*
   strcat函数作业
   */
#include <stdio.h>
char *mystrcat(char *p_dest, const char *p_src) {
	char *p_dest1 = p_dest;
	const char *p_src1 = p_src;
	//把p_dest1指针停留在前一个字符串中'\0'字符所在的位置
	while (1) {
		if (!*p_dest1) {
			break;
		}
		p_dest1++;
	}
	//把后一个字符串中每个字符追加在前一个字符串的后面
	while (1) {
		*p_dest1 = *p_src1;
		if (!*p_src1) {
			break;
		}
		p_dest1++;
		p_src1++;
	}
	return p_dest;
}
int main() {
    char str[20] = "abc"; 
	printf("%s\n", mystrcat(str, "xyz"));
	printf("%s\n", str);
	return 0;
}




