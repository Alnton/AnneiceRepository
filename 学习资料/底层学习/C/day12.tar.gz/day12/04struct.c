/*
   结构体演示
   */
#include <stdio.h>
typedef struct /*person*/ {
	int age;
	float height;
	char name[20];
} person;
//typedef struct person person;
int main() {
	//struct person person1;
	person person2 = {23, 1.73f, "abcdef"}, person3 = {};
	person *p_person = NULL;
	printf("年龄是%d\n", person2.age);
	printf("身高是%g\n", person2.height);
	printf("姓名是%s\n", person2.name);
	p_person = &person2;
	printf("年龄是%d\n", p_person->age);
	printf("身高是%g\n", p_person->height);
	printf("姓名是%s\n", p_person->name);
	person3 = person2;
	printf("年龄是%d\n", person3.age);
	printf("身高是%g\n", person3.height);
	printf("姓名是%s\n", person3.name);
	return 0;
}



