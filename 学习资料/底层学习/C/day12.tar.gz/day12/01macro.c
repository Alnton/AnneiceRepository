/*
   宏作业
   */
#include <stdio.h>
#define   CH(c)    ((c) >= 'a' && (c) <= 'z' ? (c) - 'a' + 'A' : (c) - 'A' + 'a')
int main() {
    printf("%c\n", CH('t'));
	printf("%c\n", CH('Q'));
	return 0;
}
