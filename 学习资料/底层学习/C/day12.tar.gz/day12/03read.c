#include <stdio.h>
#include "03read.h"
int num;
void read(void) {
	printf("请输入一个数字：");
	scanf("%d", &num);
}
