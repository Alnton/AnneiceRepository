#ifndef   __03READ_H__
#define   __03READ_H__
extern int num;
void read(void);
#endif   // __03READ_H__
