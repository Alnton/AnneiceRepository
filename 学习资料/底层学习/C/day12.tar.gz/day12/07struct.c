/*
   结构体练习
   */
#include <stdio.h>
#define   LEN2(p_l)   (((p_l)->pt1.row - (p_l)->pt2.row) * ((p_l)->pt1.row - (p_l)->pt2.row) + ((p_l)->pt1.col - (p_l)->pt2.col) * ((p_l)->pt1.col - (p_l)->pt2.col))
typedef struct {
	int row, col;
} pt;
typedef struct {
    pt pt1, pt2;
} line;
int main() {
    line l1 = {}, l2 = {};
	printf("请输入一个线段的位置：");
	scanf("%d%d%d%d", &(l1.pt1.row), &(l1.pt1.col), &(l1.pt2.row), &(l1.pt2.col));
	printf("请再次输入一个线段的位置：");
	scanf("%d%d%d%d", &(l2.pt1.row), &(l2.pt1.col), &(l2.pt2.row), &(l2.pt2.col));
    if (LEN2(&l1) > LEN2(&l2)) {
		printf("比较长的线段是((%d, %d),(%d,%d))\n", l1.pt1.row, l1.pt1.col, l1.pt2.row, l1.pt2.col);
	}
	else {
		printf("比较长的线段是((%d, %d), (%d, %d))\n", l2.pt1.row, l2.pt1.col, l2.pt2.row, l2.pt2.col);
	}
	return 0;
}





