/*
   结构体练习
   */
#include <stdio.h>
typedef struct {
	int row, col;
} pt;
typedef struct {
	pt pt1, pt2;
} rect;
int main() {
	rect r = {};
	rect *p_rect = &r;
	printf("请输入两个点的位置：");
	/*scanf("%d%d%d%d", &(r.pt1.row), &(r.pt1.col), &(r.pt2.row), &(r.pt2.col));
	printf("((%d,%d),(%d,%d))\n", r.pt1.row, r.pt1.col, r.pt2.row, r.pt2.col);*/
	scanf("%d%d%d%d", &(p_rect->pt1.row), &(p_rect->pt1.col), &(p_rect->pt2.row), &(p_rect->pt2.col));
	printf("((%d,%d),(%d,%d))\n", p_rect->pt1.row, p_rect->pt1.col, p_rect->pt2.row, p_rect->pt2.col);
	return 0;
}



