#include "02add.h"
int add(int num, int num1) {
	return num + num1;
}
