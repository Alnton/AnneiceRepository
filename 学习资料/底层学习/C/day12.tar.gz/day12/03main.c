/*
   多文件编程练习
   */
#include <stdio.h>
#include "03read.h"
int main() {
	read();
	printf("num是%d\n", num);
	return 0;
}
