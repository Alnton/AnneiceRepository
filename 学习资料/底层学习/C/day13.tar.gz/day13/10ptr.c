/*
   二级指针形式参数练习
   */
#include <stdio.h>
typedef struct {
	int row, col;
} pt;
typedef struct {
	pt pt1, pt2;
} rect;
int area(const rect *p_r) {
	int ret = 0;
	ret = (p_r->pt1.row - p_r->pt2.row) * (p_r->pt1.col - p_r->pt2.col);
	return ret >= 0 ? ret : 0 - ret;
}
void larger(const rect *p_r1, const rect *p_r2, rect **pp_r) {
	*pp_r = (rect *)(area(p_r1) > area(p_r2) ? p_r1 : p_r2);
}
int main() {
	rect r1 = {}, r2 = {}, *p_r = NULL;
	printf("请输入第一个长方形的位置：");
	scanf("%d%d%d%d", &(r1.pt1.row), &(r1.pt1.col), &(r1.pt2.row), &(r1.pt2.col));
	printf("请输入第二个长方形的位置：");
	scanf("%d%d%d%d", &(r2.pt1.row), &(r2.pt1.col), &(r2.pt2.row), &(r2.pt2.col));
	larger(&r1, &r2, &p_r);
	printf("比较大的长方形是((%d, %d), (%d, %d))\n", p_r->pt1.row, p_r->pt1.col, p_r->pt2.row, p_r->pt2.col);
	return 0;
}



