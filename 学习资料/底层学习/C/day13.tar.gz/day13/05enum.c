/*
   枚举类型演示
   */
#include <stdio.h>
/*typedef enum  {
	CHUN,
	XIA = 5,
	QIU,
	DONG
} season;*/
#define    CHUN          0
#define    XIA           1
#define    QIU           2
#define    DONG          3
int main() {
    //season s;
	printf("QIU是%d\n", QIU);
	return 0;
}




