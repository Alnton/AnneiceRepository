/*
   结构体作业
   */
#include <stdio.h>
#define   PI        3.14f
#define   LEN2(p_pt1, p_pt2)   (((p_pt1)->row - (p_pt2)->row) * ((p_pt1)->row - (p_pt2)->row) + ((p_pt1)->col - (p_pt2)->col) * ((p_pt1)->col - (p_pt2)->col))
typedef struct {
	int row, col;
} pt;
typedef struct {
    pt mid;
	int radius;
} circle;
int main() {
	pt pt1 = {};
    circle cl = {};
	printf("请输入点的位置：");
	scanf("%d%d", &(pt1.row), &(pt1.col));
	printf("请输入圆心的位置：");
	scanf("%d%d", &(cl.mid.row), &(cl.mid.col));
	printf("请输入圆的半径：");
	scanf("%d", &(cl.radius));
    printf("圆的周长是%g\n", 2 * PI * cl.radius);
	printf("圆的面积是%g\n", PI * cl.radius * cl.radius);
	if (LEN2(&pt1, &(cl.mid)) < cl.radius * cl.radius) {
		printf("点在圆内\n");
	}
	else if (LEN2(&pt1, &(cl.mid)) == cl.radius * cl.radius) {
		printf("点在圆上\n");
	}
	else {
		printf("点在圆外\n");
	}
	return 0;
}



