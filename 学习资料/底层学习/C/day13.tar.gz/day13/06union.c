/*
   联合演示
   */
#include <stdio.h>
typedef union {
	char ch;
	int num;
} un;
int main() {
	printf("sizeof(un)是%d\n", sizeof(un));
	return 0;
}

