/*
   数组练习
   */
#include <stdio.h>
int main() {
	int arr[][3] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	int arr1[][3] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	int arr2[3][3] = {};
	int row = 0, col = 0, num = 0;
	for (row = 0;row <= 2;row++) {
		for (col = 0;col <= 2;col++) {
			for (num = 0;num <= 2;num++) {
				arr2[row][col] += arr[row][num] * arr1[num][col];
			}
		}
	}
	for (row = 0;row <= 2;row++) {
		for (col = 0;col <= 2;col++) {
			printf("%d ", arr2[row][col]);
		}
		printf("\n");
	}
	return 0;
}




