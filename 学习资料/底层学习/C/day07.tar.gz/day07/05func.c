/*
   函数演示
   */
#include <stdio.h>
void print(void) {
	printf("%d\n", 1);
}
int main() {
	print();
	return 0;
}
