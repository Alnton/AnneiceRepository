/*
   布雷练习
   */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
	int map[10][10] = {}, row = 0, col = 0, cnt = 0, num = 0;
	int delta[][2] = {-1, -1, -1, 0, -1, 1, 0, -1, 0, 1, 1, -1, 1, 0, 1, 1};
    srand(time(0));
	//采用死循环向地图中放地雷
	while (1) {
		//获得新地雷位置
        row = rand() % 10;
		col = rand() % 10;
		if (map[row][col] != -1) {
			//如果新位置原来不是地雷就放地雷
			map[row][col] = -1;
			cnt++;
		}
		if (cnt == 10) {
			//如果地雷个数达到10个则结束循环
			break;
		}
	}
	//把地雷周围的数字补充上
	for (row = 0;row <= 9;row++) {
		for (col = 0;col <= 9;col++) {
			if (map[row][col] != -1) {
				//把不是地雷的地方排除掉
				continue;
			}
            //依次处理地雷周围的八个位置
			for (num = 0;num <= 7;num++) {
				int newrow = row + delta[num][0];
				int newcol = col + delta[num][1];
				if (newrow >= 0 && newrow <= 9 && newcol >= 0 && newcol <= 9) {
					if (map[newrow][newcol] != -1) {
						map[newrow][newcol]++;
					}
				}
			}
		}
	}
	//采用双重循环打印地图中每个位置
	for (row = 0;row <= 9;row++) {
		for (col = 0;col <= 9;col++) {
			if (map[row][col] == -1) {
				printf("X");
			}
			else if (map[row][col] > 0) {
				printf("%d", map[row][col]);
			}
			else {
				printf("O");
			}
		}
		printf("\n");
	}
	return 0;
}




