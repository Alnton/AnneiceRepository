/*
   数组作业
   */
#include <stdio.h>
int main() {
	int num = 0, arr[10] = {};
	printf("请输入一个数字：");
	scanf("%d", &num);
	while (1) {
		arr[num % 10]++;
		num /= 10;
		if (!num) {
			break;
		}
	}
    for (num = 0;num <= 9;num++) {
		if (arr[num]) {
		    printf("数字%d出现的次数是%d\n", num, arr[num]);
		}
	}
	return 0;
}



