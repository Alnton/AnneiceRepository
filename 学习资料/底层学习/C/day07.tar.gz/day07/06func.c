/*
   返回值演示
   */
#include <stdio.h>
int read() {
	int num = 0;
	printf("请输入一个数字：");
	scanf("%d", &num);
	return num;
}
int main() {
	int num = 0;
    num = read();
	printf("数字是%d\n", num);
	return 0;
}
