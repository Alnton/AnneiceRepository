/*
   变量作业
   */
#include <stdio.h>
int main() {
	int radius = 10;
	double area = 3.1415 * radius * radius;
	printf("面积是%lg\n", area);
	return 0;
}
