/*
   八进制和十六进制演示
   */
#include <stdio.h>
int main() {
	printf("0%o  %d\n", 0152, 0152);
	printf("0x%x 0X%X %d\n", 0xcb, 0xcb, 0xcb);
	return 0;
}
