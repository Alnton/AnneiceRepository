/*
   文件拷贝作业
   */
#include <stdio.h>
int main(int argc, char *argv[]) {
	int size = 0;
	char buf[100] = {};
	FILE *p_src = NULL, *p_dest = NULL;
	p_src = fopen(argv[1], "rb");
	if (!p_src) {
		printf("原文件打开失败\n");
		return 0;
	}
	p_dest = fopen(argv[2], "wb");
	if (!p_dest) {
		printf("目标文件打开失败\n");
		fclose(p_src);
		p_src = NULL;
		return 0;
	}
	while (1) {
		size = fread(buf, sizeof(char), 100, p_src);
		if (!size) {
			break;
		}
		fwrite(buf, sizeof(char), size, p_dest);
	}
	fclose(p_dest);
	p_dest = NULL;
	fclose(p_src);
	p_src = NULL;
	return 0;
}


