/*
   动态内存分配练习
   */
#include <stdio.h>
#include <stdlib.h>
typedef struct {
	int row, col;
} pt;
int main() {
    pt *p_num = (pt *)malloc(5 * sizeof(pt));
	int num = 0;
	if (p_num) {
        for (num = 1;num <= 5;num++) {
			pt *p_pt = p_num + num - 1;
			printf("请输入一个点的位置：");
			scanf("%d%d", &(p_pt->row), &(p_pt->col));
		}
		for (num = 4;num >= 0;num--) {
			pt *p_pt = p_num + num;
			printf("(%d, %d)\n", p_pt->row, p_pt->col);
		}
		free(p_num);
		p_num = NULL;
	}
	return 0;
}



