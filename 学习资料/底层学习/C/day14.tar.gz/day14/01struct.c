/*
   结构体作业
   */
#include <stdio.h>
#define   PI          3.14f
typedef struct {
	int row, col;
} pt;
typedef struct {
	pt mid;
	int radius;
} circle;
enum rela {IN, ON, OUT};
float length(const circle *p_cl) {
    return 2 * PI * p_cl->radius;
}
float area(const circle *p_cl) {
	return PI * p_cl->radius * p_cl->radius;
}
int len2(const pt *p_pt1, const pt *p_pt2) {
	return (p_pt1->row - p_pt2->row) * (p_pt1->row - p_pt2->row) + (p_pt1->col - p_pt2->col) * (p_pt1->col - p_pt2->col);
}
int relation(const pt *p_pt, const circle *p_cl) {
	if (len2(p_pt, &(p_cl->mid)) < p_cl->radius * p_cl->radius) {
		return IN;
	}
	else if (len2(p_pt, &(p_cl->mid)) == p_cl->radius * p_cl->radius) {
		return ON;
	}
	else {
		return OUT;
	}
}
int main() {
	pt pt1 = {};
	circle cl = {};
	int ret = 0;
	printf("请输入点的位置：");
	scanf("%d%d", &(pt1.row), &(pt1.col));
	printf("请输入圆的位置：");
	scanf("%d%d%d", &(cl.mid.row), &(cl.mid.col), &(cl.radius));
	printf("周长是%g\n", length(&cl));
	printf("面积是%g\n", area(&cl));
	ret = relation(&pt1, &cl);
	if (ret == IN) {
		printf("点在圆内\n");
	}
	else if (ret == ON) {
		printf("点在圆上\n");
	}
	else {
		printf("点在圆外\n");
	}
	return 0;
}






