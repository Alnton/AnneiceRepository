/*
   回调函数演示
   */
#include <stdio.h>
enum {LARGER, EQUAL, LESS};
int compare(const int *p_num, const int *p_num1) {
    if (*p_num > *p_num1) {
		return LARGER;
	}
	else if (*p_num < *p_num1) {
		return LESS;
	}
	else {
		return EQUAL;
	}
}
int compare1(const int *p_num, const int *p_num1) {
	return 2 - compare(p_num, p_num1);
}
void bubble(int *p_num, int size, int (*p_compare)(const int *, const int *)) {
	int num = 0, num1 = 0;
	for (num = size - 1;num >= 1;num--) {
        for (num1 = 0;num1 <= num - 1;num1++) {
			if (p_compare(p_num + num1, p_num + num1 + 1) == LARGER) {
				int tmp = *(p_num + num1);
				*(p_num + num1) = *(p_num + num1 + 1);
				*(p_num + num1 + 1) = tmp;
			}
		}
	}
}
int main() {
	int arr[] = {4, 2, 8, 3, 1, 6, 7};
	int num = 0;
	bubble(arr, 7, compare);
	for (num = 0;num <= 6;num++) {
		printf("%d ", arr[num]);
	}
	printf("\n");
	bubble(arr, 7, compare1);
	for (num = 0;num <= 6;num++) {
		printf("%d ", arr[num]);
	}
	printf("\n");
	return 0;
}
