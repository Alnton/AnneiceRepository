/*
   动态分配内存代码框架
   */
#include <stdio.h>
#include <stdlib.h>
int main() {
    int *p_num = (int *)malloc(5 * sizeof(int));
	/*if (p_num) {
		//
		free(p_num);
		p_num = NULL;
	}*/
	if (!p_num) {
		return 0;
	}
    //
	free(p_num);
	p_num = NULL;
	return 0;
}




