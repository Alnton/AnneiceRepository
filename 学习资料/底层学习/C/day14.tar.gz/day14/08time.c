/*
   时间函数演示
   */
#include <stdio.h>
#include <time.h>
int main() {
    time_t tm = 0;
	time(&tm);
	printf("%s\n", ctime(&tm));
	struct tm *p_tm = gmtime(&tm);
	printf("%s\n", asctime(p_tm));
	p_tm = localtime(&tm);
	printf("%s\n", asctime(p_tm));
	return 0;
}




