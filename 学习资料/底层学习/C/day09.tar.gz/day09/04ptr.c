/*
   指针演示
   */
#include <stdio.h>
int main() {
	int *p_num = NULL, *p_num1 = NULL;
	int num = 10;
	p_num = &num;
	*p_num = 5;
	printf("num是%d\n", num);
	return 0;
}
