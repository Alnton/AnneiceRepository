/*
   变量演示
   */
#include <stdio.h>
int num;
void func(void) {
    printf("num是%d\n", num);
}
int main() {
	int num = 1;
	printf("num是%d\n", num);
	func();
	return 0;
}
