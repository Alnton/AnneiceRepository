/*
   递归作业
   */
#include <stdio.h>
int func(int num) {
	if (num == 1) {
		return 1;
	}
	return num + func(num - 1);
}
int main() {
	int max = 0, sum = 0, num = 0;
	printf("请输入一个正整数：");
	scanf("%d", &max);
	/*for (num = 0;num <= max;num++) {
		sum += num;
	}*/
	sum = func(max);
	printf("求和结果是%d\n", sum);
	return 0;
}
