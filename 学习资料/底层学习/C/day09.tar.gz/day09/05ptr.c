/*
   指针练习
   */
#include <stdio.h>
int main() {
	int num = 0, num1 = 0, num2 = 0;
	int *p_num = &num, *p_num1 = &num1, *p_num2 = &num2;
	//从键盘得到三个整数并记录在三个变量里，找出其中的最大数并打印在屏幕上。程序中只能使用指针变量
	printf("请输入三个数字：");
	scanf("%d%d%d", p_num, p_num1, p_num2);
	/*if (*p_num > *p_num1) {
		if (*p_num > *p_num2) {
			printf("最大数字是%d\n", *p_num);
		}
		else {
			printf("最大数字是%d\n", *p_num2);
		}
	}
	else {
        if (*p_num1 > *p_num2) {
			printf("最大数字是%d\n", *p_num1);
		}
		else {
			printf("最大数字是%d\n", *p_num2);
		}
	}*/
	if (*p_num < *p_num1) {
		int *p_tmp = p_num;
		p_num = p_num1;
		p_num1 = p_tmp;
	}
	if (*p_num < *p_num2) {
		int *p_tmp = p_num;
		p_num = p_num2;
		p_num2 = p_tmp;
	}
	printf("最大数字是%d\n", *p_num);
	return 0;
}



