/*
   无类型指针演示
   */
#include <stdio.h>
int main() {
	int num = 10;
	void *p_v = &num;
	*(int *)p_v = 20;
	printf("num是%d\n", num);
	return 0;
}
