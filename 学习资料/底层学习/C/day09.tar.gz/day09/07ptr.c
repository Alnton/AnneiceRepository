/*
   指针形式参数演示
   */
#include <stdio.h>
void func(int arr[], int size) {
	printf("sizeof(arr)是%d\n", sizeof(arr));
}
int main() {
    int arr[5] = {};
	printf("sizeof(arr)是%d\n", sizeof(arr));
	func(arr, 5);
	return 0;
}
