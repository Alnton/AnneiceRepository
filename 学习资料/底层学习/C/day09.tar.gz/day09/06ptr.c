/*
   指针和数组关系演示
   */
#include <stdio.h>
int main() {
	int arr[] = {1, 2, 3, 4, 5};
	int *p_num = arr;
	printf("p_num[3]是%d\n", p_num[3]);
	printf("arr是%p,arr + 1是%p\n", arr, arr + 1);
	printf("p_num是%p,p_num + 1是%p\n", p_num, p_num + 1);
	printf("&arr[3] - &arr[0]是%d\n", &arr[3] - &arr[0]);
	printf("*(p_num + 2)是%d\n", *(p_num + 2));
	printf("sizeof(p_num)是%d,sizeof(arr)是%d\n", sizeof(p_num), sizeof(arr));
	printf("&arr是%p,&p_num是%p\n", &arr, &p_num);
	return 0;
}




