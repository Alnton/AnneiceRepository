/*
   const关键字演示
   */
#include <stdio.h>
int main() {
	int num = 10;
	const int *p_num = &num;
	int * const p_num1 = &num;
	//*p_num = 20;
	num = 20;
	p_num = NULL;
	*p_num1 = 20;
	p_num1 = NULL;
	return 0;
}
