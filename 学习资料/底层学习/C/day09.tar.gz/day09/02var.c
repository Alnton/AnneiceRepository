/*
   变量演示
   */
#include <stdio.h>
int num;   //全局变量
void func(void) {
	int val = 10;
	int val1 = 11;
	int val2 = val + val1;
	num = 10;
}
void func1(void) {
	static int val = 4;
	printf("val是%d\n", val);
	val = 100;
}
int main() {
	func1();
	printf("num是%d\n", num);
	func();
	printf("num是%d\n", num);
	func1();
	return 0;
}
