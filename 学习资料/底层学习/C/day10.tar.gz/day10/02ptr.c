/*
   指针作业
   */
#include <stdio.h>
void reverse(int *p_num, int size) {
	int *p_head = p_num, *p_tail = p_num + size - 1;
	while (1) {
		int tmp = 0;
		if (p_head >= p_tail) {
			//所有存储区都交换完成了
			break;
		}
		//交换配对存储区内容
        tmp = *p_head;
		*p_head = *p_tail;
		*p_tail = tmp;
		//指针和下一对存储区捆绑
		p_head++;
		p_tail--;
	}
}
int main() {
	int arr[] = {1, 2, 3, 4, 5}, num = 0;
	reverse(arr, 5);
	for (num = 0;num <= 4;num++) {
		printf("%d ", arr[num]);
	}
	printf("\n");
	return 0;
}


