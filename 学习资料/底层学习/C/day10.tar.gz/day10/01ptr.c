/*
   指针作业
   */
#include <stdio.h>
int main() {
	int arr[5] = {}, num = 0;
	int *p_num = arr;
    /*for (num = 0;num <= 4;num++) {
		//arr[num] = 3;
		*(p_num + num) = 3;
	}*/
	for (p_num = arr;p_num <= arr + 4;p_num++) {
		*p_num = 3;
	}
	p_num = arr;
	for (num = 0;num <= 4;num++) {
		printf("%d ", *(p_num + num));
	}
	printf("\n");
	return 0;
}


