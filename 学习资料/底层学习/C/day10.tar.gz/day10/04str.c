/*
   字符串演示
   */
#include <stdio.h>
int main() {
	//char str[10] = {'a', 'b', 'c'};
	//char str[] = {'a', 'b', 'c'};
	char str[] = "abc";
	printf("sizeof(str)是%d\n", sizeof(str));
	return 0;
}
