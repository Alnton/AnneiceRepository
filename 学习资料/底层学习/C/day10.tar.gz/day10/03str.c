/*
   字符串演示
   */
#include <stdio.h>
int main() {
	int num = 0;
	char *p_str = "abcdef", *p_str1 = "abcdef", *p_str2 = "abc""def";
	printf("p_str是%p,p_str1是%p, p_str2是%p\n", p_str, p_str1, p_str2);
	//*p_str = 'y';   错误
    num = *(p_str + 6);
	printf("num是%d\n", num);
	return 0;
}





