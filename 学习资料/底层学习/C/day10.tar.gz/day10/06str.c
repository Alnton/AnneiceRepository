/*
   字符串函数演示
   */
#include <stdio.h>
#include <stdlib.h>
int main() {
	char str[20] = {};
	int num = 26;
	char ch = 't';
	float fnum = 4.7f;
	//printf("%d %c %g\n", num, ch, fnum);
	sprintf(str, "%d %c %g", num, ch, fnum);
	printf("%s\n", str);
	sscanf("p 2.4 62", "%c %g %d", &ch, &fnum, &num);
	printf("%g %c %d\n", fnum, ch, num);
	num = atoi("486");
	printf("num是%d\n", num);
	fnum = atof("3.7");
	printf("fnum是%g\n", fnum);
	return 0;
}



