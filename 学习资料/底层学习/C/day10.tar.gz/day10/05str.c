/*
   字符串函数演示
   */
#include <stdio.h>
#include <string.h>
int main() {
	char str[20] = "abcdef";
	printf("有效字符个数是%d\n", strlen(str));
	printf("sizeof(str)是%d\n", sizeof(str));
	printf("%s\n", strcat(str, "xyz"));
	printf("%s\n", str);
	printf("比较结果是%d\n", strcmp("abc", "abd"));
	printf("%s\n", strcpy(str, "xyz"));
	printf("%s\n", str);
	memset(str, 'h', 3);
	printf("%s\n", str);
	strcpy(str, "abcdef");
	printf("%s\n", strstr(str, "cde"));
	return 0;
}


