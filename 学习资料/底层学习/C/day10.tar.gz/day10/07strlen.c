/*
   strlen函数练习
   */
#include <stdio.h>
int mystrlen(const char *p_str) {
	int cnt = 0;
	const char *p_tmp = p_str;
	while (1) {
		if (*p_tmp) {
			cnt++;
		}
		else {
			break;
		}
		p_tmp++;
	}
	return cnt;
}
int main() {
    int num = mystrlen("abcdef");
	printf("有效字符个数是%d\n", num);
	return 0;
}
