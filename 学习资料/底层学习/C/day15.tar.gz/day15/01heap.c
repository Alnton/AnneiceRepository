/*
   动态内存分配作业
   */
#include <stdio.h>
#include <stdlib.h>
char *mystrcpy(const char *p_str) {
	const char *p_str1 = p_str;
	char *p_dest = NULL;  //动态分配内存首地址
	int cnt = 0;   //统计的字符个数
	while (1) {
		//统计字符个数
		if (!*p_str1) {
			//如果遇到'\0'则结束循环
			break;
		}
		p_str1++;
		cnt++;
	}
	cnt++;  //把'\0'字符的个数加上
	p_dest = (char*)malloc(cnt * sizeof(char));
	if (p_dest) {
		char *p_dest1 = p_dest;
		p_str1 = p_str;
		while (1) {
			//逐个字符复制
            *p_dest1 = *p_str1;
			if (!*p_str1) {
				break;
			}
			p_str1++;
			p_dest1++;
		}
	}
	return p_dest;
}
int main() {
    char *p_str = mystrcpy("abcdef");
	if (p_str) {
		printf("%s\n", p_str);
		free(p_str);
		p_str = NULL;
	}
	return 0;
}




