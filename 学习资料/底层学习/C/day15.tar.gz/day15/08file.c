/*
   fscanf函数演示
   */
#include <stdio.h>
int main() {
	char ch = 0;
	float fnum = 0.0f;
	int num = 0;
	FILE *p_file = fopen("b.txt", "r");
	if (p_file) {
		//scanf("%c %g %d", &ch, &fnum, &num);
		fscanf(p_file, "%c %g %d", &ch, &fnum, &num);
		printf("%g %d %c\n", fnum, num, ch);
		fclose(p_file);
		p_file = NULL;
	}
	return 0;
}
