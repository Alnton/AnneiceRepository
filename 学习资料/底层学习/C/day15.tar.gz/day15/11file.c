/*
   人员信息管理系统
   */
#include <stdio.h>
typedef struct {
	int id;
	float salary;
	char name[20];
} person;
int main() {
	int id = 0;
	person p = {};
	printf("请输入要查找的id:");
	scanf("%d", &id);
	FILE *p_file = fopen("person.bin", "rb");
	if (p_file) {
		while (1) {
			if (!fread(&p, sizeof(person), 1, p_file)) {
				break;
			}
			if (p.id == id) {
			    printf("id是%d,工资是%g,姓名是%s\n", p.id, p.salary, p.name);
			}
		}
		fclose(p_file);
		p_file = NULL;
	}
	return 0;
}




