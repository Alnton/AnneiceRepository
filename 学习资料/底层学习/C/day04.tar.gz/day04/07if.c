/*
   if分支练习
   */
#include <stdio.h>
int main() {
	int gender = 0, weight = 0, height = 0;
	printf("请输入性别，身高和体重：");
	scanf("%d%d%d", &gender, &height, &weight);
    if (gender && (height - weight < 105)) {
		printf("超重的男人\n");
	}
	else if (!gender && (height - weight < 110)) {
		printf("超重的女人\n");
	}
	else {
		printf("不超重的人\n");
	}
	return 0;
}



