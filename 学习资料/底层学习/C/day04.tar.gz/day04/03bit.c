/*
   位操作符演示
   */
#include <stdio.h>
int main() {
	int num = 0xffffffff;
	unsigned int unum = 0xffffffff;
	printf("3 & 5是%d\n", 3 & 5);
	printf("3 | 5是%d\n", 3 | 5);
	printf("3 ^ 5是%d\n", 3 ^ 5);
	printf("3 << 2是%d\n", 3 << 2);
	printf("num >> 2是%x\n", num >> 2);
	printf("unum >> 2是%x\n", unum >> 2);
	return 0;
}



