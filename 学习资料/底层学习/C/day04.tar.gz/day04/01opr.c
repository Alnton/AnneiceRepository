/*
   操作符作业
   */
#include <stdio.h>
int main() {
	int num = 0, num1 = 0, num2 = 0, num3 = 0, sum = 0;
	printf("请输入四个数字：");
	scanf("%d%d%d%d", &num, &num1, &num2, &num3);
	//sum = num + num1 + num2 + num3;
	sum += num;
	sum += num1;
	sum += num2;
	sum += num3;
	printf("求和结果是%d\n", sum);
	return 0;
}



