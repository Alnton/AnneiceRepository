/*
   三目表达式演示
   */
#include <stdio.h>
int main() {
	int num = 0, ret = 0;
	printf("请输入一个整数：");
	scanf("%d", &num);
	ret = num >= 0 ? num : 0 - num;
	printf("绝对值是%d\n", ret);
	return 0;
}
