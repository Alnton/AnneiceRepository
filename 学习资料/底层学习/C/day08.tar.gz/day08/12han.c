/*
   汉诺塔演示
   */
#include <stdio.h>
void han(int num, char begin, char middle, char end) {
	if (num == 1) {
		printf("%d:%c-->%c\n", num, begin, end);
		return ;
	}
	han(num - 1, begin, end, middle);
	printf("%d:%c-->%c\n", num, begin, end);
	han(num - 1, middle, begin, end);
}
int main() {
	int num = 0;
	printf("请输入盘子的个数：");
	scanf("%d", &num);
	han(num, 'a', 'b', 'c');
	return 0;
}


