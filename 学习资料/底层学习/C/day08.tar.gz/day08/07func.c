/*
   函数练习
   */
#include <stdio.h>
int sum(int arr[], int size) {
	int num = 0, ret = 0;
	for (num = 0;num <= size - 1;num++) {
        ret += arr[num];
	}
	return ret;
}
int main() {
	int arr[] = {1, 2, 3, 4, 5};
	int res = sum(arr, 5);
	printf("求和结果是%d\n", res);
	return 0;
}
