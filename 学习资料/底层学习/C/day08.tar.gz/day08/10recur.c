/*
   递归函数练习
   */
#include <stdio.h>
int func(int num) {
	if (num == 1) {
		return 1;
	}
	return num * func(num - 1);
}
int main() {
    int num = func(5);
	printf("结果是%d\n", num);
	return 0;
}
