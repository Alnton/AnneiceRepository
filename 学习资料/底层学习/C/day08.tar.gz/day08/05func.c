/*
   函数声明演示
   */
#include <stdio.h>
int main() {
	int num = add(2, 6);
	printf("求和结果是%d\n", num);
	return 0;
}
double add(double num, double num1) {
	return num + num1;
}
