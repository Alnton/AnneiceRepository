/*
   函数参数练习
   */
#include <stdio.h>
void print(int num, int num1) {
	printf("%d X %d = %d\n", num, num1, num * num1);
}
int main() {
	int num = 0;
	/*print(1, 9);
	print(2, 8);
	print(3, 7);
	print(4, 6);
	print(5, 5);*/
	for (num = 1;num <= 5;num++) {
		print(num, 10 - num);
	}
	return 0;
}


