/*
   形式参数演示
   */
#include <stdio.h>
void print(int num, int num1) {
	printf("%d %d\n", num, num1);
}
int main() {
    print(2, 3);
	print(4, 5);
	return 0;
}



