/*
   递归练习
   */
#include <stdio.h>
int fei(int num, int arr[], int size) {
	if (num <= 1) {
		return 1;
	}
	if (!arr[num - 2]) {
		arr[num - 2] = fei(num - 2, arr, size);
	}
	if (!arr[num - 1]) {
		arr[num - 1] = fei(num - 1, arr, size);
	}
	return arr[num - 2] + arr[num - 1];
}
int main() {
	int arr[50] = {};
	int num = 0, ret = 0, num1 = 1, num2 = 1, val = 0;
	printf("请输入一个编号：");
	scanf("%d", &num);
    //ret = fei(num, arr, 50);
    for (val = 2;val <= num;val++) {
		int tmp = num1 + num2;
		num1 = num2;
		num2 = tmp;
		/*num2 = num1 + num2;
		num1 = num2 - num1;*/
	}
	printf("编号为%d的数字是%d\n", num, num2);
	//printf("编号为7的数字是%d\n", ret);
	return 0;
}
